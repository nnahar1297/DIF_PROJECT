import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;

import java.io.IOException;
import java.util.Iterator;

public class NetworkJobsReducer extends MapReduceBase
        implements Reducer<Text, IntWritable, Text, DoubleWritable> {

    @Override
    public void reduce(Text key, Iterator<IntWritable> values,
                       OutputCollector<Text, DoubleWritable> output, Reporter reporter) throws IOException {

        int sum = 0;
        int count = 0;

        while (values.hasNext()) {
            IntWritable val = values.next();
            sum += val.get();
            count++;
        }

        if (count > 0) {
            double avgJobOffers = (double) sum / count;
            output.collect(key, new DoubleWritable(avgJobOffers));
        }
    }
}
