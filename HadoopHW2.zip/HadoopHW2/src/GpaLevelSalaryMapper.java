import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import java.io.IOException;

public class GpaLevelSalaryMapper extends MapReduceBase
        implements Mapper<LongWritable, Text, Text, DoubleWritable>{

    @Override
    public void map(LongWritable key, Text value, OutputCollector<Text, DoubleWritable> output,
                    Reporter reporter) throws IOException {
        String[] cols = value.toString().split("\\s+");

        if (key.get() == 0)
            return;

        double gpa = Double.parseDouble(cols[2]);
        double salary = Double.parseDouble(cols[7]);

        if (gpa > 3.5) {
            output.collect(new Text("GPA_High"), new DoubleWritable(salary));
        }
        else {
            output.collect(new Text("GPA_Low"), new DoubleWritable(salary));
        }
    }
}
