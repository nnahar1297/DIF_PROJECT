import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import java.io.IOException;

public class InternshipJobsMapper extends MapReduceBase
        implements Mapper<LongWritable, Text, Text, IntWritable> {

    @Override
    public void map(LongWritable key, Text value, OutputCollector<Text, IntWritable> output,
                    Reporter reporter) throws IOException {
        String[] cols = value.toString().split("\\s+");

        if (key.get() == 0)
            return;

        int internship = Integer.parseInt(cols[3]);
        int job = Integer.parseInt(cols[6]);

        if (internship >= 3) {
            output.collect(new Text("Internship_High"), new IntWritable(job));
        }
        else {
            output.collect(new Text("Internship_Low"), new IntWritable(job));
        }
    }
}
